import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const dir=new URL('./',import.meta.url),root=new URL('../../',import.meta.url);
const sha=x=>createHash('sha256').update(x).digest('hex');
const read=f=>JSON.parse(fs.readFileSync(new URL(f,dir)));
const names=['final-pool-play-water.json','final-pool-coastal-halls.json'];
const reports=names.map(read),inventory=read('baseline-source-inventory.json'),slots=read('final-slot-inventory.json');
for(const q of reports){assert.equal(q.pass,true);assert.equal(q.baseline,inventory.baseline);assert.deepEqual(q.pool,reports[0].pool);}
const cases=reports.flatMap(q=>q.cases);
assert.equal(cases.length,10);
assert.equal(new Set(cases.map(c=>c.k+':'+c.v)).size,10);
assert.deepEqual(cases.map(c=>c.k+':'+c.v).sort(),slots.rows.map(c=>c.k+':'+c.v).sort());
for(const c of cases){assert.equal(c.pass,true);assert.deepEqual(c.viewports.map(v=>v.width),[1440,360,412]);assert.equal(c.negativeControls.length,12);for(const v of c.viewports){assert.equal(v.covered,v.required);assert.equal(v.rawThreeExact,true);assert.equal(v.bounds.fitsViewport,true);}}
for(const[file,pin]of Object.entries(inventory.files))assert.equal(sha(fs.readFileSync(new URL(file,root))),pin.sha256,'baseline source bytes remain unchanged: '+file);
const result={baseline:inventory.baseline,qualification:'Complete published D081 scene with all 130 prior exact models enabled. Baseline-only Node ray qualification; not candidate geometry, WebGL appearance, physical-phone acceptance, CI or publication. Exact joint ten-slot pool and original production cameras plus unchanged predetermined 24-angle pool. No mandatory sample or silhouette removed. All full-owner bounds, neighbors, original age400 owners and ordered trees retained.',pool:reports[0].pool,sourceFilesVerified:Object.keys(inventory.files).length,sourceInventorySha256:sha(fs.readFileSync(new URL('baseline-source-inventory.json',dir))),classifierSha256:sha(fs.readFileSync(new URL('tools/d081-frame.mjs',root))),reports:Object.fromEntries(names.map(n=>[n,sha(fs.readFileSync(new URL(n,dir)))])),totals:{ownerCases:cases.length,ownerWidthCases:cases.flatMap(c=>c.viewports).length,rawThreeExactCases:cases.flatMap(c=>c.viewports).filter(v=>v.rawThreeExact).length,required:cases.flatMap(c=>c.viewports).reduce((a,v)=>a+v.required,0),covered:cases.flatMap(c=>c.viewports).reduce((a,v)=>a+v.covered,0),negativeControls:cases.reduce((a,c)=>a+c.negativeControls.length,0),emptyTreeCases:slots.rows.reduce((a,c)=>a+c.treeEmptyCases,0)},cases:cases.map(c=>({k:c.k,v:c.v,owner:c.owner,site:c.site,sceneDigest:c.sceneDigest,construction:c.construction,ownerConstruction:c.ownerConstruction,worldSha256:c.worldSha256,sourceWorldSha256:c.sourceWorldSha256,tableHeight:c.tableHeight,renderHeight:c.renderHeight,selected:c.selected,widths:c.viewports.map(v=>({width:v.width,required:v.required,covered:v.covered,contractSha256:v.contractSha256,sourceGeometrySha256:v.sourceGeometrySha256,cameraRows:v.cameraRows}))})),pass:true};
const output=new URL('final-summary.json',dir);assert.ok(!fs.existsSync(output));fs.writeFileSync(output,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({sha256:sha(fs.readFileSync(output)),...result.totals}));
