// D081 read-only OLD feasibility against the complete published D081 renderer.
// Only diagnostic scripts/evidence under scratch/d081 may be written.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {D081_KT,d081City,d081Blocks,d081Civic} from '../../tools/unit-d081.mjs';
import {buildCityScene} from '../../src/render/cityScene.ts';
import {STYLES} from '../../src/render/styles.ts';
import {ConState} from '../../src/render/construction.ts';
import {sceneDigest} from '../../src/render/digest.ts';
import {d081OwnerSurfaceContract,d081OwnerSurfaceRayAudit,assertD081SurfaceCoverage,d081OwnerBounds,assertD081OwnerFits,fitD081PairedOwnerView,d081ConstructionDiagnostic,d081OwnerConstruction,d081DetailAlpha} from '../../tools/d081-frame.mjs';

const ROOT=new URL('../../',import.meta.url),OUT=new URL('./',import.meta.url);
const baseline='2cd43c424dcc909dcfa6ac55275406d2bc527ce0';
const sha=b=>createHash('sha256').update(b).digest('hex');
const jsonSha=o=>sha(JSON.stringify(o));
const slots=s=>s.split(',').map(v=>v.split(':').map(Number));
assert.ok(process.env.POOL&&process.env.SLOTS&&process.env.REPORT,'explicit bounded POOL, SLOTS and fresh REPORT are required');
const pool=slots(process.env.POOL),selectedSlots=slots(process.env.SLOTS);
assert.equal(new Set(pool.map(s=>s.join(':'))).size,pool.length);
assert.ok(selectedSlots.every(s=>pool.some(p=>p[0]===s[0]&&p[1]===s[1])));
const reportName=process.env.REPORT;
assert.match(reportName,/^[a-z0-9-]+$/);
const outputName=reportName+'.json';
assert.ok(!fs.existsSync(new URL(outputName,OUT)),'never overwrite prior evidence');
execFileSync('git',['merge-base','--is-ancestor',baseline,'HEAD'],{cwd:ROOT});
assert.equal(execFileSync('git',['rev-parse','HEAD:src'],{cwd:ROOT,encoding:'utf8'}).trim(),execFileSync('git',['rev-parse',baseline+':src'],{cwd:ROOT,encoding:'utf8'}).trim(),'doc-only descendant retains exact baseline source tree');
const inventory=JSON.parse(fs.readFileSync(new URL('baseline-source-inventory.json',OUT)));
assert.equal(inventory.baseline,baseline);
function verifySources(){for(const [file,pin]of Object.entries(inventory.files))assert.equal(sha(fs.readFileSync(new URL(file,ROOT))),pin.sha256,'baseline bytes remain exact: '+file);}
verifySources();
const viewports=[{W:1440,H:1000},{W:360,H:740},{W:412,H:860}];
const legalAngles=[];
for(const elevation of [Math.PI*.08,Math.PI/6,Math.PI*.32])for(let yaw=0;yaw<8;yaw++)legalAngles.push({yaw:yaw*Math.PI/4,elevation});
assert.equal(legalAngles.length,24);
function camera(n,b,vp,{yaw=0,elevation=Math.PI/6}={}){
 const D=n*1.6,x=b.x+b.size/2,z=b.z+b.size/2,c=Math.cos(yaw),s=Math.sin(yaw),radius=D*Math.sqrt(2+2*Math.tan(Math.PI/6)**2),h=radius*Math.cos(elevation)/Math.SQRT2;
 const target=[x,0,z],zoom=Math.max(.6,Math.min(8,.70*.84*n*(vp.W/vp.H)/(b.size*Math.SQRT2)));
 assert.ok(elevation>=Math.PI*.08-1e-12&&elevation<=Math.PI*.32+1e-12);
 return elevation===Math.PI/6?{pos:[x+D*(c-s),D*Math.SQRT2*Math.tan(Math.PI/6),z+D*(s+c)],target,zoom}:{pos:[x+h*(c-s),radius*Math.sin(elevation),z+h*(s+c)],target,zoom};
}
function fixture(sample,v){
 const source=d081City(sample),sourceWorldSha256=jsonSha(source),city={...source,buildings:source.buildings.map(b=>pool.some(([k,u])=>k===b.k&&u===v)?{...b,v}:b)};
 const con=new ConState(city.n),built=buildCityScene(city,D081_KT,STYLES.A,d081Blocks(city),'d',d081Civic(true),con,true);
 if(built.con)con.setGeometry(built.con.top,built.con.base,built.con.wallTop);
 con.setCity(city,k=>D081_KT.cat(k));built.setTreeAges(i=>con.siteAge(i));con.uni.uDayFrac.value=0;con.uni.uTime.value=2.2;
 assert.equal(jsonSha(source),sourceWorldSha256,'original world never changed');
 return {city,n:city.n,scene:built.scene,meshes:built.buildingMeshes(),owners:built.pickOwners(),digest:sceneDigest(built),construction:d081ConstructionDiagnostic(built.scene,con),worldSha256:jsonSha(city),sourceWorldSha256,built,con,dispose(){built.dispose();con.dispose();}};
}
function writeFresh(file,value){assert.ok(!fs.existsSync(new URL(file,OUT)),'never overwrite evidence '+file);fs.writeFileSync(new URL(file,OUT),JSON.stringify(value,null,2));}
function save(){fs.writeFileSync(new URL(outputName,OUT),JSON.stringify(report,null,2));}
const report={baseline,pool,slots:selectedSlots,viewports,legalAngles,sourceFilesVerified:Object.keys(inventory.files).length,classifierSha256:sha(fs.readFileSync(new URL('tools/d081-frame.mjs',ROOT))),qualification:'Complete immutable published D081 renderer and all prior 120 models enabled. OLD Node-only feasibility, never candidate or WebGL acceptance. Exactly24 predetermined legal angles and exact original production camera. Four points of every triangle and every original silhouette record retained. Full owner, neighbors and ordered trees remain. Stop a candidate after a decisive impossible width; untouched widths/owners/variants remain untested.',ownerInventory:Object.fromEntries(['gallery','seed516','ai120'].map(sample=>[sample,d081City(sample).buildings.filter(b=>pool.some(([k])=>k===b.k)&&b.goneDay===undefined&&b.x>=0&&b.z>=0&&b.x+b.size<=d081City(sample).n&&b.z+b.size<=d081City(sample).n)])),cases:[],pass:false};
let failed=0;
for(const [k,v]of selectedSlots){
 let slotFailed=false;
 for(const sample of ['gallery','seed516','ai120']){
  if(slotFailed)break;
  const src=d081City(sample),targets=src.buildings.filter(b=>b.k===k&&b.goneDay===undefined&&b.x>=0&&b.z>=0&&b.x+b.size<=src.n&&b.z+b.size<=src.n);
  for(const target of targets){
   const f=fixture(sample,v),b=f.city.buildings.find(b=>b.id===target.id),key=`${sample}-k${k}-v${v}-owner${b.id}`;
   const row={key,k,v,sample,owner:b.id,site:b,tableHeight:D081_KT.height(k,b.lv,v),renderHeight:Math.max(.12,D081_KT.height(k,b.lv,v)),sourceWorldSha256:f.sourceWorldSha256,worldSha256:f.worldSha256,sceneDigest:f.digest,construction:f.construction,ownerConstruction:d081OwnerConstruction(f.city,f.con,b.id),viewports:[],selected:[],negativeControls:[],pass:false};
   console.log(new Date().toISOString(),'START',key);
   const states=[];
   try{
    for(const vp of viewports){
     const original=camera(f.n,b,vp),bounds=d081OwnerBounds(f,original,vp,b.id),contract=d081OwnerSurfaceContract(f,original,vp,b.id),rawContract=d081OwnerSurfaceContract(f,original,vp,b.id,{testOnlyRawSilhouetteRays:true});
     assert.deepEqual(contract,rawContract,'complete ordered rawThree contract equality');
     assert.equal(contract.probes.length,contract.triangleCount*4+contract.originalHits);
     const originalAudit=bounds.fitsViewport?d081OwnerSurfaceRayAudit(f,original,vp,contract):null;
     const originalVisible=new Set(originalAudit?.visibleSamples??[]),remainingProbes=contract.probes.filter(p=>p.required&&!originalVisible.has(p.id));
     const audits=[];
     for(const [i,descriptor]of legalAngles.entries()){
      const base=camera(f.n,b,vp,descriptor),fit=fitD081PairedOwnerView([f,f],base,vp,b.id);
      assertD081OwnerFits(d081OwnerBounds(f,fit.view,vp,b.id));
      const audit=d081OwnerSurfaceRayAudit(f,fit.view,vp,{...contract,probes:remainingProbes});
      audits.push({i,descriptor,view:fit.view,bounds:fit.bounds[0],audit});
     }
     const union=new Set([...(originalAudit?.visibleSamples??[]),...audits.flatMap(a=>a.audit.visibleSamples)]),missing=contract.requiredSamples.filter(id=>!union.has(id));
     const state={vp,original,bounds,contract,rawContract,originalAudit,audits,missing};states.push(state);
     console.log(new Date().toISOString(),'WIDTH',key,vp.W,'required',contract.requiredSamples.length,'covered',union.size,'originalFits',bounds.fitsViewport,'rawThree',true);
     if(missing.length||!bounds.fitsViewport){
      row.decisiveFailure={width:vp.W,reason:!bounds.fitsViewport?'Exact original production camera does not fit full owner':'Complete mandatory contract cannot be covered by original plus fixed24 legal angles',missing:missing.map(id=>({probe:contract.probes.find(p=>p.id===id),observations:[{view:'original',sample:originalAudit?.samples.find(p=>p.id===id)??null},...audits.map(a=>({view:a.i,descriptor:a.descriptor,sample:a.audit.samples.find(p=>p.id===id)}))]})),untestedWidths:viewports.slice(states.length).map(v=>v.W)};
      slotFailed=true;failed++;break;
     }
    }
    if(!slotFailed){
     const needed=new Set(states.flatMap(c=>c.contract.requiredSamples.map(id=>c.vp.W+':'+id))),covered=new Set(states.flatMap(c=>(c.originalAudit?.visibleSamples??[]).map(id=>c.vp.W+':'+id))),remaining=[...legalAngles.keys()],selected=[];
     while(covered.size<needed.size){let best=-1,gain=0;for(const i of remaining){const add=new Set(states.flatMap(c=>c.audits[i].audit.visibleSamples.map(id=>c.vp.W+':'+id)).filter(id=>!covered.has(id)));if(add.size>gain){best=i;gain=add.size;}}assert.ok(best>=0,'complete legal-angle union already proved');selected.push(best);remaining.splice(remaining.indexOf(best),1);for(const c of states)for(const id of c.audits[best].audit.visibleSamples)covered.add(c.vp.W+':'+id);row.selected.push({index:best,...legalAngles[best],gain});}
     for(const c of states){c.selected=selected.map(i=>({...c.audits[i],audit:d081OwnerSurfaceRayAudit(f,c.audits[i].view,c.vp,c.contract)}));c.coverage=assertD081SurfaceCoverage([c.originalAudit,...c.selected.map(a=>a.audit)],c.contract);}
     for(const c of states)for(const[name,predicate]of [['wall',p=>Math.abs(p.normal[1])<.1],['roof',p=>p.normal[1]>.1]])for(const mode of ['missing','reversed']){
      const probe=c.contract.probes.find(p=>p.required&&p.source==='fixed-triangle'&&predicate(p));assert.ok(probe,'mandatory '+name);const mesh=f.meshes[probe.mesh],original=mesh.geometry,changed=original.clone(),a=changed.attributes.position.array,t=probe.triangle*9;
      try{if(mode==='missing')for(let j=0;j<9;j++)a[t+j]=a[t+j%3];else for(let j=0;j<3;j++)[a[t+3+j],a[t+6+j]]=[a[t+6+j],a[t+3+j]];mesh.geometry=changed;const audits=[c.original,...c.selected.map(a=>a.view)].map(view=>d081OwnerSurfaceRayAudit(f,view,c.vp,c.contract));assert.throws(()=>assertD081SurfaceCoverage(audits,c.contract),/every fixed exterior point/);row.negativeControls.push({width:c.vp.W,name,mode,rejected:true,probe:probe.id});}finally{mesh.geometry=original;changed.dispose();}
     }
     row.pass=true;
    }
    for(const c of states){
     const views=[c.original,...(c.selected??[]).map(a=>a.view)],cameraRows=views.map(view=>{const labZoom=Math.SQRT2*c.vp.H*view.zoom/(f.n*.84)/64;return{view,labZoom,uDetail:d081DetailAlpha(labZoom)};});
     row.viewports.push({width:c.vp.W,bounds:c.bounds,contractSha256:c.contract.sha256,sourceGeometrySha256:c.contract.sourceGeometrySha256,rawThreeExact:true,triangles:c.contract.triangleCount,fixed:c.contract.fixedTriangleSamples,required:c.contract.requiredSamples.length,covered:c.contract.requiredSamples.length-c.missing.length,retained:c.contract.probes.length,originalHits:c.contract.originalHits,originalBlockedHits:c.contract.originalBlockedHits,coverage:c.coverage??null,missing:c.missing,cameraRows});
     writeFresh(`${reportName}-${key}-${c.vp.W}.json`,{contract:c.contract,rawContract:c.rawContract,original:{view:c.original,bounds:c.bounds,audit:c.originalAudit},selected:c.selected??[],discoveryOnlyRemainingRequiredPoints:c.audits,missing:c.missing,coverage:c.coverage??null,cameraRows});
    }
    assert.deepEqual(sceneDigest(f.built),f.digest,'exact complete original scene digest retained after controls');
    assert.deepEqual(d081ConstructionDiagnostic(f.built.scene,f.con),f.construction,'complete ordered trees and construction remain unchanged');
    assert.equal(jsonSha(f.city),f.worldSha256,'copied world remains unchanged');
   }catch(error){if(!slotFailed)failed++;slotFailed=true;row.error=error.stack;console.error('ERROR',key,error.stack);}
   finally{f.dispose();report.cases.push(row);save();}
   console.log(new Date().toISOString(),'RESULT',JSON.stringify({key,pass:row.pass,counts:row.viewports.map(c=>[c.width,c.covered,c.required]),selected:row.selected,negativeControls:row.negativeControls.length,decisiveFailure:row.decisiveFailure?{width:row.decisiveFailure.width,missing:row.decisiveFailure.missing.length,untestedWidths:row.decisiveFailure.untestedWidths}:null}));
   if(slotFailed)break;
  }
 }
}
verifySources();
report.pass=failed===0;
report.totals={ownerCases:report.cases.length,ownerWidthCases:report.cases.reduce((n,c)=>n+c.viewports.length,0),rawThreeExactCases:report.cases.flatMap(c=>c.viewports).filter(v=>v.rawThreeExact).length,required:report.cases.flatMap(c=>c.viewports).reduce((n,v)=>n+v.required,0),covered:report.cases.flatMap(c=>c.viewports).reduce((n,v)=>n+v.covered,0),negativeControls:report.cases.reduce((n,c)=>n+c.negativeControls.length,0)};
save();console.log('COMPLETE',report.pass,JSON.stringify(report.totals));process.exitCode=failed?1:0;
